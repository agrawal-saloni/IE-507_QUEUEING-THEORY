lm = input("Enter the value of lambda: ");
mu = input("Enter the value of mu: ");
k = input("Enter the value of k: ");
t = input("Enter the value of t: ");
i_print = input("Do you want to print intermediate values? (1 or 0): ");
x0 =k;
l0 =0;
x = zeros(t,1);
l = zeros(t,1);
j = zeros(t,1);
rs = [];
b = 0;
mean_rs =0;

for i = 1:1000
    b = estimateATM(lm,mu,k,x0,l0,x,l,j,t,i_print);
   rs = [rs b];
end



function [Z] = estimateATM(lm,mu,k,x0,l0,x,l,j,t,i_print)
    Z=0;
    z = kCapacityATM(lm,mu,k,x0,l0,x,l,j,t);
    if i_print == 1
        disp(z);
    end
    Z = z(length(z));
end


function count = JobsDoneInOneArrival(l,mu,x0)
a = exprnd(1/l);
count = 0;
tou= 0;
 for i=1:x0
    t1 = exprnd(1/mu);
    tou = tou+t1;
    if tou <= a
        count= count+1;

    else
        break;
    end
 end

end

function p = kCapacityATM(lm,mu,k,x0,l0,x,l,j,t)
for i=1:t

  if i == 1
      j(1) = JobsDoneInOneArrival(lm,mu,x0);
    x(1) = min(k,(x0-j(1)+1));
    if x0 -j(1) == k 
            l(1) = l0 +1;
    else
            l(1) = l0;
    end

  else
      j(i) = JobsDoneInOneArrival(lm,mu,x(i-1));
      x(i) = min(k,(x(i-1)-j(i)+1));
        
      if x(i-1) -j(i) == k 
           l(i) = l(i-1) +1;
      else
            l(i) = l(i-1);
      end
  end 
end

 p = [];
  if t>100
    for i=1:100:t
      p = [p l(i)/i];
    end
 else
    for i=1:t
       p = [p l(i)/i];
   end
  end

end

    
plot(z);
grid on;
title("Fraction of people lost v/s time");
xlabel("T");
ylabel("LT/T");

figure;

histogram(rs);

mean_rs = mean(rs);
fprintf("Mean of the random sample generated = %f", mean_rs);