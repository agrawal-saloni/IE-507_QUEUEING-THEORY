n = input("Enter the value of n: ");
l = input("Enter the value of lambda: ");
T = input("Enter the value of T: ");
z = [];
for i=1:n
    b = z_gen(n,l,T);
    z = [z b];
end

function [z1] = z_gen(n,l,T)
x = [];
y = [];
z1 = 0;
for i = 1:n
    x(i) = exprnd(1/l);
end
y(1) = x(1);
for i=2:n
    y(i) = y(i-1) + x(i);
end
for i = 1:n
    if y(i) >=T
        z1 = i-1;
        break;
    end
end
end

histogram(z);
fprintf("avg = %f", mean(z));


