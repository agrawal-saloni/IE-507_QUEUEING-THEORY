n = input("Enter the value of n: ");
l = input("Enter the value of lambda: ");

for i = 1:5
    wlln(n,l);
end

function[] = wlln(n,l)
x = zeros(n,1);
y = zeros(n,1);
z = zeros(n,1);
z_new = [];
z_new_2 = [];
k = 1:400;

for i =1:n
    x(i) = exprnd(1/l);
end
y(1) = x(1);
for i=2:n
    y(i) = y(i-1)+x(i);
    z(i) = y(i)/i;
end

for i= 1:2000
    z_new(i) = z(i);
end

%histogram(z_new);
for i =1:400
    z_new_2(i) = z(i);
end 

plot(k,z_new_2);
hold on;
end