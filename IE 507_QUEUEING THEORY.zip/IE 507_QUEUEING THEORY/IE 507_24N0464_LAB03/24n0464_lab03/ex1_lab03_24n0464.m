n = input("Input the value of n: ");
l1 = input("Enter lambda1: ");
l2 = input("Enter lambda2: ");

x1 = zeros(n,1);
x2 = zeros(n,1);
y = zeros(n,1);
    for i=1:n
        x1(i)=  exprnd(1/l1);
        x2(i)= exprnd(1/l2);
        y(i)=  min(x1(i),x2(i));
    end

histogram(y);
title("histogram of min(x1,x2)");
figure;
