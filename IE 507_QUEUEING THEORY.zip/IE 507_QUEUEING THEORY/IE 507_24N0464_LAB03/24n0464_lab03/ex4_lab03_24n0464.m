x = 100;
%t1 is the sequence of job completion times which is exponential with
%parameter mu

l = input("Enter the value of lambda: ");
mu = input("Enter the value of mu: ");
z = [];

for i=1:10000
    a = JobsDoneInOneArrival(l,mu);
    z = [z a];
end


function [k] = JobsDoneInOneArrival(l,mu)
t1 = [ ];
t2 = [ ];
y = [ ];
t = [ ];
k =0;

for i = 1:100
    t1(i) = exprnd(1/mu);
    t2(i) = exprnd(1/l);
end
%t2 is the arrival time of the next job

y(1) = t1(1);
for i=2:100
    y(i) = y(i-1)+t1(i);
end
for i=1:100
    if y(i)>=t2(i+1)
        k = i-1;
        break;
    end
end
end

histogram(z);
fprintf("%f", mean(z));
