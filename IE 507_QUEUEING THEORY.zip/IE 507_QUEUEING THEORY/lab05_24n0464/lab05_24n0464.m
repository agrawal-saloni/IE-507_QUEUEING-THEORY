lm = 9
mu = 10
T = 5000
k = 1

j = 0;
x = 0;
b = 0;
x0 = 0;
b0= 0;

busy_fraction = busyfractioninkATM(lm,mu,k,T,x0,b0,x,j,b);
disp(busy_fraction)

%theoretical values
if k==1
  disp(mu/(mu+lm))
end
if k==2
    disp((mu+lm)*lm/(lm*lm + mu*mu + lm*mu));
end

for i =1:20000:T
    busy_fraction = busyfractioninkATM(lm,mu,k,T,x0,b0,x,j,b);
    disp(busy_fraction)
end


function [busyfrac] = busyfractioninkATM(lm,mu,k,T,x0,b0,x,j,b)
    b_atm = kcapacityATM(lm,mu,k,x0,x,j,b,b0,T);
    busyfrac = b_atm/T;
end

function count = joa(lm,mu,x0)
    count = 0;
    t=0;
    sm=0;
    a = exprnd(1/lm);
    for i=1:x0
        t = exprnd(1/mu);
        sm = sm+t;
        if sm <= a
            count = count+1;
        end
    end
end

function [b0] = kcapacityATM(lm,mu,k,x0,x,j,b,b0,T)
    for i=1:T
        if i==1
            j = joa(lm,mu,x0);
            x = min(k,x0-j+1);
        else
            j = joa(lm,mu,x);
               if x-j>0
                b = b+1;
               end
            x = min(k, x-j+1);
        end

    end
        b0 = sum(b);
end

