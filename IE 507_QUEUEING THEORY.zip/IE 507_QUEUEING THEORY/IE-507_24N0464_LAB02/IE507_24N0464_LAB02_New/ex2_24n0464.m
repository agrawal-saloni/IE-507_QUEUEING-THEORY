%Exercise: 2
%loading the data from a file
x = load('ex2a.dat');
m = input("Enter the value of m");

%executing the function
ex2fun(x,m);

%creating the function
function [] = ex2fun(a,m)
    n = size(a,1);
    q = fix(n/m);
%creating a zero vector to store the new values
    cb = zeros(q,1);
    b = zeros(q,1);
%Calculating the cumulative values to be stored in the new column vector b
    for i = 1:q
        for j =1:m*i
            cb(i) = cb(i) + a(j);
        end
    end
%Calculating the new column vector b
    b(1) = cb(1);

    for i=2:q
         b(i) = cb(i) - cb(i-1);
    end

%printing the new vector
    for i=1:q
        fprintf('%f\n', b(i));
    end
%Finding the number of elements in the vector and printing them
    Number_elements_b = size(b,1);
    fprintf('Number of elements in matrix b is: %d\n', Number_elements_b);

%Calculating the required values
    minval = min(b);
    maxval = max(b);
    avgval = mean(b);
    std_dev = std(b);

%Printing the values
    fprintf(['Minimum value = %.2f\n  Maximum Value = %.2f\n Average = %.2f\n  ' ...
        'Standard Deviation = %.2f'], minval, maxval, avgval, std_dev);

%Creating a histogram to check the distribution of the data entered
    histogram(b);
    title('Histogram for values of b');
    xlabel("b");
    ylabel("frequency");
end
%We find that this histogram is depicting a normally distributed data
%We can now input different values of m and observe the results 