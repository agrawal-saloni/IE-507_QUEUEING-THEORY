%Exercise:4
%generating demand and supply for 2000 days
n = 2000;
dem = 20+ (40-20)*rand(n,1);
supp = 20+ (40-20)*rand(n,1);

cost_per_litre = input("Enter the cost of the milk per litre.");
sellp_per_litre = input("Enter the selling price of the milk per litre");
sellp_excess = input("Enter the selling price of the excess milk per litre");

avg_rev  = zeros(n,1);
 
 for i = 1:n
        avg_rev(i) = min(dem(i), supp(i))*sellp_per_litre;
        if supp(i) - dem(i) >0
            avg_rev(i) = avg_rev(i)+ (supp(i) - dem(i))*sellp_excess;
        end
 end

 for i = 2:n
     for j = 1:i-1
         avg_rev(i) = avg_rev(i)+ avg_rev(j);
     end
     avg_rev(i) = avg_rev(i)/i;
 end

 for i=1:n
     fprintf("%.2f\n", avg_rev(i));
 end

%average profits at the end of every 50 days
q = n/50;
cum_avg = zeros(q,1);

for i=1:q
    for j=1:50*i
        cum_avg(i) = cum_avg(i)+avg_rev(j);
    end
    cum_avg(i) = cum_avg(i)/(50*i);
end

 for i=1:q
     fprintf("Day = %d, Average till now= %.2f\n", 50*i, cum_avg(i));
 end

 days = zeros(q,1);
 for i=1:q
     days(i) = 50*i;
 end

 plot(days, cum_avg);
 title = ('Cumulative averages v/s days');
 hold on;
 grid on;
 hold off;

