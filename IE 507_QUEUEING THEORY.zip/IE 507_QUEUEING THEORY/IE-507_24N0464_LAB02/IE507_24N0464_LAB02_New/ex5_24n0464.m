%Exercise:5
n = input("Enter the value of n: ");
testrand(n);
testrand_exp(n);
testrand_exp_new(n);

%function to generate random numbers between 0 and 1
%and test their uniformity
function [] = testrand(n)
x = [n,1];
    for i =1:n
        x(i) = rand();
    end
    histogram(x);
    title("Distribution of random numbers generated using testrand")
    xlabel('X');
    ylabel('Frequency of x');
    figure;
end

%the same done using exprnd function
function [] = testrand_exp(n)
x = [n,1];
    for i =1:n
        x(i) = exprnd(0.5);
    end
    histogram(x);
    title("Distribution of random numbers generated using exprand")
    xlabel('X');
    ylabel('Frequency of x');
    figure;
end

%part:3 removing values less than 0.5 
function [] = testrand_exp_new(n)
x = [n,1];
count =0;
    for i =1:n
        x(i) = exprnd(0.5);
        if x(i)<0.5
            x(i) = [];
            count = count+1;
        else
            x(i) = x(i) -0.5;
        end
    end
    histogram(x);
    title("Distribution of random numbers generated using exprand and discarded")
    xlabel('X');
    ylabel('Frequency of x');

fprintf("Numbers discarded = %d\n", count);
fprintf("Fraction of numbers discarded = %.2f\n", count/n);
end