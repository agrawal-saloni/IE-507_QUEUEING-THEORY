%Exercise: 3
%Loading the supply and demand data 
 
dem = load("demand.dat");
supp = load('supply.dat');
n = size(dem, 1);

cost_per_litre = input("Enter the cost of the milk per litre.");
sellp_per_litre = input("Enter the selling price of the milk per litre");
sellp_excess = input("Enter the selling price of the excess milk per litre");

%calculating the profits
prof = zeros(n,1);
    for i = 1:n
        prof(i) = min(supp(i),dem(i))*sellp_per_litre - supp(i)*cost_per_litre ;
        if supp(i) - dem(i) >0
            prof(i) = prof(i)+ (supp(i) - dem(i))*sellp_excess;
        end
    end
    %printing the profits
    for i = 1:n
        fprintf('%.2f\n', prof(i));
    end


%major graphs and charts
hist(prof);
title("Distribution of profits over days");
xlabel("Profit");
ylabel("Frequency");
figure;
boxplot(prof);
title("Profit distribution");
figure; 
fprintf('The size of the profit vector is %d\n', size(prof,1));

%major statistics related to the shop
%profit statsitics
totalprof = sum(prof);
avgprof = mean(prof);
var_prof = var(prof);
med_prof = median(prof);

fprintf("The total profi" + ...
    "t made in the past two years is %.2f\n", totalprof);
fprintf("The average profit made in the past two years is %.2f\n", avgprof);
fprintf("The variance in the profit made in the past two years is %.2f\n", var_prof);
fprintf("The median profit made in the past two years is %.2f\n", med_prof);


%Calculating cumulative monthly profits
cum_mon_prof = zeros(24,1);
for j = 1: 31
        cum_mon_prof(1) = cum_mon_prof(1) + prof(j);
end
for i = 2:24
    if mod(i,2)==0 
        for j =1:30*i
            cum_mon_prof(i) = cum_mon_prof(i) + prof(j);
        end
    else
        for j =1:31*i
            cum_mon_prof(i) = cum_mon_prof(i) + prof(j);
        end
         
    end
end

mon_prof = zeros(24,1);
mon_prof(1) = cum_mon_prof(1);

for i=2:24
    mon_prof(i) = cum_mon_prof(i) - cum_mon_prof(i-1);
end

for i = 1:24
    fprintf('%d   %.2f\n',i, mon_prof(i));
end

avgprof_mon = mean(mon_prof);
medprof_mon = median(mon_prof);
maxmon_prof = max(mon_prof);
minmon_prof = min(mon_prof);
var_mon_prof = var(mon_prof);

fprintf("The average monthly profits made in the past two years is %.2f\n", avgprof_mon);
fprintf("The median monthly profit made in the past two years is %.2f\n", medprof_mon);
fprintf("The maximum monthly profit made in the past two years is %.2f\n", maxmon_prof);
fprintf("The minimum monthly profit made in the past two years is %.2f\n", minmon_prof);
fprintf("The variance of the monthly profits made in the past two years is %.2f\n", var_mon_prof);

%brief analysis
hist(mon_prof);
title("Histogram for monthly profits");
figure;
plot(mon_prof);
title("Profits v/s months");
figure;
boxplot(mon_prof);
ylabel("Profits");
title("Boxplot for monthly profits");
figure;

%part 3
%calculation of profits when the milk can be stored for two days, i.e.
%selling the milk to the confectioner at the end of second day

add_supp = zeros(n,1);
new_prof = zeros(n,1);

%calculating the new supply matrix 

for i = 2:n
    if supp(i-1) > dem(i-1)
        add_supp(i) = supp(i-1) - dem(i-1);
    end
end

%new profits
new_prof(1) = min(dem(1), supp(1))*sellp_per_litre - supp(1)*cost_per_litre;

for i = 2:n
    if dem(i)<supp(i)
        new_prof(i) = dem(i)*sellp_per_litre - supp(i)*cost_per_litre+ add_supp(i)*sellp_excess;
    elseif dem(i)>supp(i)
        if dem(i)>supp(i)+add_supp(i)
            new_prof(i) = supp(i)*sellp_per_litre - supp(i)*cost_per_litre + add_supp(i)*sellp_per_litre;
        else
            new_prof(i) = supp(i)*sellp_per_litre - supp(i)*cost_per_litre + (add_supp(i) - (dem(i)- supp(i)))*sellp_excess + (dem(i)- supp(i))*sellp_per_litre;
        end

    end
end

for i = 1:n
    fprintf('%.2f\n', new_prof(i));
end

%new profit statsitics
new_totalprof = sum(new_prof);
new_avgprof = mean(new_prof);
new_var_prof = var(new_prof);
new_med_prof = median(new_prof);

fprintf("The total new profit made in the past two years is %.2f\n", new_totalprof);
fprintf("The average new profit made in the past two years is %.2f\n", new_avgprof);
fprintf("The variance in the new profit made in the past two years is %.2f\n", new_var_prof);
fprintf("The median new profit made in the past two years is %.2f\n", new_med_prof);


